import React, {Component} from 'react';

export default class CreatPost extends Component {}