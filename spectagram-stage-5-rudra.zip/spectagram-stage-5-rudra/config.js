export const firebaseConfig = {
    apiKey: "AIzaSyDOOt0jmaNUS19FwdxkaaQaCRl_Aht5w0U",
    authDomain: "spectagram-app-11f30.firebaseapp.com",
    projectId: "spectagram-app-11f30",
    storageBucket: "spectagram-app-11f30.appspot.com",
    messagingSenderId: "662479808228",
    appId: "1:662479808228:web:9237984bdef3881488aef1"
  };